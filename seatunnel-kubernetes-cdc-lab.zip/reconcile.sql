SELECT (SELECT COUNT(*) FROM shop.orders) AS source_rows,
       (SELECT COUNT(*) FROM reporting.orders) AS target_rows;
SELECT COUNT(*) AS missing_rows FROM shop.orders s LEFT JOIN reporting.orders t ON s.id=t.id WHERE t.id IS NULL;
SELECT COUNT(*) AS extra_rows FROM reporting.orders t LEFT JOIN shop.orders s ON s.id=t.id WHERE s.id IS NULL;
SELECT COUNT(*) AS changed_rows FROM shop.orders s JOIN reporting.orders t ON s.id=t.id WHERE NOT(BINARY s.status <=> BINARY t.status) OR NOT(s.amount <=> t.amount);
SELECT id,status,amount FROM reporting.orders WHERE id IN (1,2,50001,100000,100001,100002) ORDER BY id;
