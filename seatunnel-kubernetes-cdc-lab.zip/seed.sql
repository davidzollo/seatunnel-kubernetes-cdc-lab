CREATE DATABASE shop;
CREATE DATABASE reporting;
CREATE USER 'cdc'@'%' IDENTIFIED BY 'Article02_cdc_only';
GRANT SELECT, SHOW DATABASES, REPLICATION SLAVE, REPLICATION CLIENT, RELOAD ON *.* TO 'cdc'@'%';
CREATE USER 'writer'@'%' IDENTIFIED BY 'Article02_writer_only';
GRANT SELECT,INSERT,UPDATE,DELETE ON reporting.* TO 'writer'@'%';
CREATE TABLE shop.orders (id INT PRIMARY KEY, status VARCHAR(20) NOT NULL, amount DECIMAL(12,2) NOT NULL);
CREATE TABLE reporting.orders LIKE shop.orders;
CREATE TABLE shop.digit (n INT PRIMARY KEY);
INSERT INTO shop.digit VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9);
INSERT INTO shop.orders SELECT 1+a.n+10*b.n+100*c.n+1000*d.n+10000*e.n,'created',10.00
FROM shop.digit a CROSS JOIN shop.digit b CROSS JOIN shop.digit c CROSS JOIN shop.digit d CROSS JOIN shop.digit e;
DROP TABLE shop.digit;
