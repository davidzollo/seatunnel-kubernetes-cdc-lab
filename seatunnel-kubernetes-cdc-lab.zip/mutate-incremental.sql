UPDATE shop.orders SET status='shipped', amount=45.50 WHERE id=2;
INSERT INTO shop.orders VALUES(100002,'created',19.90);
DELETE FROM shop.orders WHERE id=100001;
